:-use_module(library(trill_inc)).

:- trill.

/** <examples>

% AR
?- prob_instanceOf(phd,a,Prob).

*/

classAssertion(postdoc,a).
classAssertion(prof,a).
classAssertion(postdoc,b).
propertyAssertion(advise,a,b).
subClassOf(postdoc,phd).
subClassOf(prof,phd).
subClassOf(postdoc,complementOf(prof)).
disjointClasses([postdoc,someValuesFrom(advise,phd)]).
annotationAssertion('disponte:probability',classAssertion(postdoc,a),literal('0.2')).
annotationAssertion('disponte:probability',classAssertion(prof,a),literal('0.8')).
annotationAssertion('disponte:probability',classAssertion(postdoc,b),literal('0.2')).
annotationAssertion('disponte:probability',propertyAssertion(advise,a,b),literal('0.8')).
%annotationAssertion('disponte:probability',subClassOf(intersectionOf([pr,phd]),sem),literal('1.0')).
%annotationAssertion('disponte:probability',subClassOf(unionOf([pr,phd]),sem),literal('1.0')).
%annotationAssertion('disponte:probability',disjointClasses([pr,phd]),literal('1.0')).