name(trill_inc).
title('A modified version of TRILL to cope with inconsistent KB').
version('1.5.0').
author('Riccardo Zese', 'zsercr@unife.it').
requires(bddem).
